package com.example.cinecamera.mixin;

import com.example.cinecamera.CineCamera;
import net.minecraft.client.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Camera.class)
public abstract class CameraMixin {
	// Surum farkina karsi birden fazla aday isim; require=0 -> olmayan isim hata vermez.
	@Inject(method = {"setup", "update", "alignWithEntity"}, at = @At("TAIL"), require = 0)
	private void cinecamera$apply(CallbackInfo ci) {
		CineCamera.apply((Camera) (Object) this);
	}

	// 1. sahista "detached" gibi davran -> oyuncunun kendi govdesi cizilir.
	@Inject(method = "isDetached", at = @At("HEAD"), cancellable = true, require = 0)
	private void cinecamera$detached(CallbackInfoReturnable<Boolean> cir) {
		if (CineCamera.fullBodyActive()) cir.setReturnValue(true);
	}
}
